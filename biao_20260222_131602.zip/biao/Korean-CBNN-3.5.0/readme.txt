만든 사람: A2NE(EX3)
(@aine3_synth)

recording = 269
alias = 1679

- **3.5 version of reclist**
- 한국어 조합식(Korean CBNN) 녹음 리스트입니다!
- 실속을 중시한 개편을 통해 대폭 녹음량이 줄었습니다... 
- 개편 이전의 풀버전 리스트를 원하실 경우. "full(풀버전을 원한다면 이쪽)" 폴더를 열어 주세요! (주의: 많이 빡셉니다)

[About Guide BGM]
- "guideBGM" 폴더에 A3~Db5까지의 bgm(120bpm)이 있어요!

[Abstract]
받침에 따라 앞 모음에 접미사가 붙는 음원 형식입니다.
접미사는 대강 이렇습니다.
ㅁ받침(m) = 1 (ex: 맘 ma1 am)
ㄴ받침(n) = 2 (ex: 산 sa2 an) 
ㅇ받침(ng) = 3 (ex: 강 ga3 ang) 
ㄹ받침(l) = 4 (ex: 물 mu4 ul) 
[Example]
* 고 양 이
{- go, o y, ya3, ang, i}
* 강 아 지
{- ga3, ang, a, a j, ji}


[원음설정(otoing)]
- 포함되어 있는 oto.ini를 사용해 원설하면 됩니다. (프로토타입 음원의 G4 음계에서 사용된 oto.ini입니다)
- 동봉된 가이드 bgm의 칼박을 잘 맞추셨다면(?) 아마 별 문제 없이 싱크가 맞을 거에요 💚
- 2.0까지의 CBNN과는 완전히 원음설정 방식이 달라졌으니 주의해 주세요! 원음설정 가이드는 추후 업데이트됩니다. (영어 Arpasing과 비슷하게 원설해 주시면 되는데(?) 정 모르시겠다면 최대한 동봉된 oto.ini의 파라미터를 우려먹어 주시면 됩니다...)

[프로토타입 음원(Prototype) - 프로토타입 음원입니다! 동봉된 가이드 bgm으로 작업한 4음계 음원이에요.]
https://ex3exp.github.io/VB-dister/pages/nero-kor-cbnn.html

[Reference]
장향실. 2014. "외국인을 위한 한국어 발음 교육에서 음운의 제시 순서 연구". 한국언어문화학, 11(3): 221-245