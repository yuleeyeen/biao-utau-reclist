만든 사람: A2NE(EX3)
(@aine3_synth)

recording = 606
alias = 3390

- **2.0.0 version of reclist**
- 한국어 조합식(Korean CBNN) 녹음 리스트입니다!
- (tmi... CBNN은 ComBiNatioN의 약자입니다)

<전체 음소를 녹음할래요!> >>> "ALL" 폴더 (추천)

<cv 음소만 녹음할래요!> >>> "cv only" 폴더
<cvc 음소만 녹음할래요!> >>> "cvc only" 폴더
<v 음소만 녹음할래요!> >>> "v only" 폴더


[About Guide BGM]
- 개인적으로는 OneNoteJazz가 좋은 듯 해요! (100BPM)
https://drive.google.com/drive/u/0/folders/0B43rIhv9uaxIaXpOZXBJLUROUnM?resourcekey=0-Ddyb8YlNse1CMV50PJxgZw

[Abstract]
- 기본적으로 한국어 cvc와 비슷하지만, 받침 앞쪽의 모음 음소 구현에 초점을 맞춘 녹음 리스트입니다!
- OpenUtau 포네마이저가 존재합니다. 
- 최대한 녹음할 때 목에 무리가 가지 않도록 음소를 배치해 발음 편의성을 극대화했습니다... 다음계 만들어 주세요(이거 아닙니다)

- 한국어 cvc에 있는 음소들을 기본적으로 전부 보유하고 있습니다. cvc 음원을 개조해서 cbnn으로 만드는 시도도... 할 만하다고 생각합니다(?) 
(아무튼 ㄹㄹ(l) 음소의 경우 보유하고 있지 않습니다!)
- 뒤에 오는 받침에 따라 앞쪽 CV에 붙는 접미사가 달라집니다.

(★주의: 모음 뒤에는 접미사가 없습니다! 따라서 포네마이저를 사용할 경우, 더 자연스러운 발음 구현을 위해 '받침 앞에서 첫음절로 오는 모음'들이 'ㅎ 계열 소리'로 변환되어 배치됩니다. 갑자기 ㅎ 소리가 튀어나온다고 해서(?) 버그가 아니니 겁먹지 말아 주세요(?))
ex: 알 {a al / - ha4 al} 살 {sa4 al / - sa4 al}) 

접미사는 다음과 같습니다.
ㅁ받침(m) = 1 (ex: 맘 ma1 am)
ㄴ받침(n) = 2 (ex: 산 sa2 an)
ㅇ받침(ng) = 3 (ex: 강 ga3 ang)
ㄹ받침(l) = 4 (ex: 물 mu4 ul)

[Example]
* 고 양 이
{- go, o y, ya3, ang, i}
* 강 아 지
{- ga3, ang, a, a j, ji}


[원음설정(otoing)]
- 테스트를 해 가면서 원설하는 것을 추천합니다!
- 포함되어 있는 oto.ini를 사용해 원설하세요.

- 자세한 듀토리얼은 하단 링크를 참조!
https://github.com/EX3exp/UTAU-Korean-CBNN/blob/main/README.md#3-how-to-otoing

[프로토타입 음원(Prototype) - 음원형식 개발과 동시에 배포한 프로토타입 음원입니다. 원음설정하다가 헷갈린다면 네로의 원설창을 훔쳐봐 주세요(?)(네?)]
https://inthe6788.wixsite.com/nero-the-black-cat/utau

[ustx 샘플]
https://www.youtube.com/watch?v=fNeIBDnApuE
 마땅하게 테스트해 볼 ustx가 없다면 가져가서 사용해 보세요!
소소하게... CBNN 조교 팁들도 함께 가져갈 수 있을지도.

[Reference]
현재까지 공개된 모든 UTAU 한국어 음원 형식들
NANA/ OpenUtau Korean CVC Phonemizer
장향실. 2014. "외국인을 위한 한국어 발음 교육에서 음운의 제시 순서 연구". 한국언어문화학, 11(3): 221-245